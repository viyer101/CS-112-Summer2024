package prereqchecker;
import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.*;

/**
 * 
 * Steps to implement this class main method:
 * 
 * Step 1:
 * AdjListInputFile name is passed through the command line as args[0]
 * Read from AdjListInputFile with the format:
 * 1. a (int): number of courses in the graph
 * 2. a lines, each with 1 course ID
 * 3. b (int): number of edges in the graph
 * 4. b lines, each with a source ID
 * 
 * Step 2:
 * EligibleInputFile name is passed through the command line as args[1]
 * Read from EligibleInputFile with the format:
 * 1. c (int): Number of courses
 * 2. c lines, each with 1 course ID
 * 
 * Step 3:
 * EligibleOutputFile name is passed through the command line as args[2]
 * Output to EligibleOutputFile with the format:
 * 1. Some number of lines, each with one course ID
 */
public class Eligible {
    //private static Map<String, List<String>> adjList = new HashMap<>();
    //private static Set<String> finishedCourses = new HashSet<>();
    //private static ArrayList<Courses> courseList;

    public static void main(String[] args) {

        if ( args.length < 3 ) {
            StdOut.println("Execute: java -cp bin prereqchecker.Eligible <adjacency list INput file> <eligible INput file> <eligible OUTput file>");
            return;
        }

    // WRITE YOUR CODE HERE

        //adjlistinputfile
        String adjListFile = args[0];
        StdIn.setFile(adjListFile);
        try {
            Map<String, List<String>> adjList = readAdjList(adjListFile);

            //eligibleinputfile
            Set<String> finishedCourses = new HashSet<>();
            StdIn.setFile(args[1]);
            int numberOfCourses = StdIn.readInt();
            StdIn.readLine();

            for (int i = 0; i < numberOfCourses; i++)
            {
                String course = StdIn.readLine();
                gatherPreReqCourses(adjList, course, finishedCourses);
            }

            //outputfile
            Set<String> eligibleCourseList = eligibleCourses(adjList, finishedCourses);
            StdOut.setFile(args[2]);
            for (String currCourse : eligibleCourseList)
            {
                StdOut.println(currCourse);
            }

            StdOut.close();
        }

        catch(Exception e)
        {
            System.out.println("Error writing outputfile:" + e.getMessage());
        }



        
    }

    public static Set<String> eligibleCourses(Map<String, List<String>> adjList, Set<String> finishedCourses)
    {
        Set<String> eligibleCourses = new HashSet<>();
        for (String course : adjList.keySet())
        {
            if (!finishedCourses.contains(course) && finishedCourses.containsAll(adjList.get(course))) //checks if the course isn't taken and if the prerequisite courses for that course are completed
                eligibleCourses.add(course); //adds to eligible courses.
        }
        return eligibleCourses;
    }

    public static Map<String, List<String>> readAdjList(String filename) throws IOException {
        Map<String, List<String>> adjList = new HashMap<>();
        BufferedReader reader = new BufferedReader(new FileReader(filename)); //sets up the filereader for the adjlistinput file.
        
        // Read number of courses
        int numCourses = Integer.parseInt(reader.readLine().trim());
        
        // Initialize all courses in the adjacency list
        for (int i = 0; i < numCourses; i++) {
            String course = reader.readLine().trim();
            adjList.put(course, new ArrayList<>());
        }
        // Read number of prereqs
        int numPrereqs = Integer.parseInt(reader.readLine().trim());
        // Populate the adjacency list with prerequisites
        for (int i = 0; i < numPrereqs; i++) {
            String[] parts = reader.readLine().trim().split(" ");
            String course = parts[0]; //takes the main target course
            String prereq = parts[1]; //takes the prereq course
            adjList.get(course).add(prereq); //aligns the two next to each other
        }
        
        reader.close();
        return adjList; //returns the hashamp
    }
    
    public static void gatherPreReqCourses(Map<String,List<String>> adjList, String course, Set<String> completedCourses)
    {
        Queue<String> courses = new LinkedList<>();
        courses.add(course);

        while (!courses.isEmpty())
        {
            String currCourse = courses.remove();
            if (!completedCourses.contains(currCourse))
            {
                completedCourses.add(currCourse);
                List<String> prereqCourses = adjList.get(currCourse);
                if (prereqCourses != null)
                {
                    for (String prereq : prereqCourses)
                    {
                        if (!completedCourses.contains(prereq))
                            courses.add(prereq);
                    }
                }
            }
        }
    }

    // private static void readFinishedCourses(String filename) throws Exception {
    //     List<String> lines = Files.readAllLines(Paths.get(filename));
    //     int c = Integer.parseInt(lines.get(0));

    //     for (int i = 0; i < c; i++)
    //     {
    //         finishedCourses.add(lines.get(i).trim());
    //     }
    // }

    // public static ArrayList<String> gatherAllPreReqs(String course) {
    //     ArrayList<String> prerequisites = new ArrayList<>();
    //     Queue<String> queue = new LinkedList<>();
    //     Set<String> visitedCourses = new HashSet<>();

    //     queue.add(course);
    //     visitedCourses.add(course);

    //     while (!queue.isEmpty())
    //     {
    //         String currCourse = queue.poll();
    //         List<String> directPreReqs = adjList.get(currCourse);
    //         if (directPreReqs != null)
    //         {
    //             for (String prereq : directPreReqs)
    //             {
    //                 if (!visitedCourses.contains(prereq))
    //                 {
    //                     visitedCourses.add(prereq);
    //                     queue.add(prereq);
    //                     prerequisites.add(prereq);
    //                 }
    //             }
    //         }            
    //     }

    //     return prerequisites;
    // }

    // private static int getCourseIndex(String courseID, ArrayList<ArrayList<String>> adjList) {
    //     for (int i = 0; i < adjList.size(); i++) {
    //         if (adjList.get(i).get(0).equals(courseID)) {
    //             return i;
    //         }
    //     }
    //     return -1; // Return -1 if the course is not found
    // }

    // private static boolean courseEligibility(String course)
    // {
    //     List<String> directPreReqCourses = adjList.get(course);
        
    //     if (!directPreReqCourses.isEmpty())
    //     {
    //         List<String> allPreReqCourses = gatherAllPreReqs(course);

    //         for (String prereqCourse : allPreReqCourses)
    //         {
    //             if (!finishedCourses.contains(prereqCourse))
    //                 return false;
    //             else
    //                 return true;
    //         }
    //     }
    //     else
    //         return true;
        
    //     return false;
    // }
}