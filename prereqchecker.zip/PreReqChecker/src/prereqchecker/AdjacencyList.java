package prereqchecker;
import java.util.*;


public class AdjacencyList {
    private Map<String, ArrayList<String>> adjList;

    public AdjacencyList()
    {
        this.adjList = new HashMap<>();
    }

    public void put(String course, ArrayList<String> prereqs)
    {
        if (!adjList.containsKey(course))
            adjList.put(course, new ArrayList<>(prereqs));
        else
            adjList.get(course).addAll(prereqs);
    }

    public void addAll(String course, ArrayList<String> prerequisites) {
        adjList.computeIfAbsent(course, k -> new ArrayList<>()).addAll(prerequisites);
    }


    public Map<String, ArrayList<String>> getAdjList()
    {
        return adjList;
    }

    public boolean containsKey(String course)
    {
        return adjList.containsKey(course);
    }

}