package prereqchecker;
import java.util.*;

/**
 * Steps to implement this class main method:
 * 
 * Step 1:
 * AdjListInputFile name is passed through the command line as args[0]
 * Read from AdjListInputFile with the format:
 * 1. a (int): number of courses in the graph
 * 2. a lines, each with 1 course ID
 * 3. b (int): number of edges in the graph
 * 4. b lines, each with a source ID
 * 
 * Step 2:
 * NeedToTakeInputFile name is passed through the command line as args[1]
 * Read from NeedToTakeInputFile with the format:
 * 1. One line, containing a course ID
 * 2. c (int): Number of courses
 * 3. c lines, each with one course ID
 * 
 * Step 3:
 * NeedToTakeOutputFile name is passed through the command line as args[2]
 * Output to NeedToTakeOutputFile with the format:
 * 1. Some number of lines, each with one course ID
 */
public class NeedToTake {
    public static void main(String[] args) {

        if (args.length < 3) {
            StdOut.println(
                    "Execute: java NeedToTake <adjacency list INput file> <need to take INput file> <need to take OUTput file>");
            return;
        }

        // WRITE YOUR CODE HERE

        StdIn.setFile(args[0]);
        ArrayList<Courses> courseList = AdjList.createListOfCourses();
        StdOut.setFile(args[2]);

        
        StdIn.setFile(args[1]);

        String courseWanted = StdIn.readLine();

        ArrayList<String> requiredCourses = new ArrayList<String>();
        ArrayList<String> tempList = new ArrayList<String>(); 

        Courses targetCourse = null;

        // find course wanted through list and it pre requisites
        for (int i = 0; i < courseList.size(); i++) {
            if (!courseList.get(i).getCourseName().equals(courseWanted))
                continue;
            else
                targetCourse = courseList.get(i);
        }

        // finds classes taken and adds to list if not present
        ArrayList<String> takenCourses = finishedCourses(courseList);

        requiredCourses = coursesRequired(takenCourses, requiredCourses, targetCourse, courseList);

        // add classes to list if not present
        for (String course : requiredCourses) {
            if (!tempList.contains(course))
                tempList.add(course);
        }

        printList(tempList);
    } 

    public static void printList(ArrayList<String> list) {
        for (int i = 0; i < list.size(); i++) {
            StdOut.println(list.get(i));
        }
    }

    public static ArrayList<String> coursesRequired(ArrayList<String> takenCourses, ArrayList<String> requiredCourses, Courses courseWanted, ArrayList<Courses> finishedCourses) {
        ArrayList<String> prereqList = courseWanted.getPreReqCourses();
        Courses course = null;
        if (!takenCourses.contains(courseWanted.getCourseName())) {
            for (int i = 0; i < prereqList.size(); i++) {
                String prereq = prereqList.get(i);
                if (takenCourses.contains(prereq)) {
                    continue;
                }
                for(int m = 0; m < finishedCourses.size(); m++) {
                    if(finishedCourses.get(m).getCourseName().equals(prereq)) {
                        course = finishedCourses.get(m);
                    }
                }
                courseWanted = course;
                requiredCourses.add(prereq);
                ArrayList<String> neededCourses = coursesRequired(takenCourses, requiredCourses, courseWanted, finishedCourses);
                requiredCourses.addAll(neededCourses);
            }
        } else {

            return requiredCourses;

        }
        return requiredCourses;
    }

    public static ArrayList<String> finishedCourses(ArrayList<Courses> adjList) { //gathers all previously completed courses
        int numOfCourses = Integer.parseInt(StdIn.readLine());
        ArrayList<String> finishedPreReqCourses = new ArrayList<String>(); //declare and create an arraylist of completed prereqs
        ArrayList<String> finalCourseList = new ArrayList<String>(); //courselist to be returned

        for (int i = 0; i < numOfCourses; i++) {
            String prereq = StdIn.readLine();
            finishedPreReqCourses.add(prereq);
        }

        for (int i = 0; i < finishedPreReqCourses.size(); i++) {
            String courseName = finishedPreReqCourses.get(i);
            Courses currentCourse = null;

            for (int j = 0; j < adjList.size(); j++) {
                if (!adjList.get(j).getCourseName().equals(courseName)) {
                } else {
                    currentCourse = adjList.get(j);
                }
            }

            ArrayList<String> neededCourses = new ArrayList<String>();
            neededCourses = completedCourses(adjList, currentCourse, neededCourses);

            finalCourseList.add(courseName);
            finalCourseList.addAll(neededCourses);

        }
        int size = 0; 

        ArrayList<String> coursesDone = new ArrayList<String>(); //create a temporary list of completed course to be traversed
        if (size != 0)
        {
            finalCourseList = addCourses(coursesDone);
        }
        
        for (String finishedCourse : coursesDone) {
            if (!finalCourseList.contains(finishedCourse)) {
                finalCourseList.add(finishedCourse);
            }
        }

        return finalCourseList;

    }

    public static ArrayList<String> completedCourses(ArrayList<Courses> courseList, Courses currentCourse, ArrayList<String> neededCourses) {
        
        String tempCourse; 
        Courses courseWanted;

        if (!currentCourse.getPreReqCourses().isEmpty()) { 
            neededCourses.addAll(currentCourse.getPreReqCourses());
            ArrayList<String> neededList = currentCourse.getPreReqCourses();
            for (int i = 0; i < neededList.size(); i++) {

                tempCourse = neededList.get(i);
                courseWanted = null;

                for (int j= 0; j < courseList.size(); j++) {
                    if (courseList.get(j).getCourseName().equals(tempCourse)) {
                        courseWanted = courseList.get(j);
                    }
                }
                ArrayList<String> finalList = completedCourses(courseList, courseWanted, neededCourses);
                neededCourses.addAll(finalList);
            }

        } else if(currentCourse.getPreReqCourses().isEmpty()){
            return neededCourses;
        }

        return neededCourses;
    }

    public static ArrayList<String> addCourses(ArrayList<String> addedList) {

        ArrayList<String> newList = new ArrayList<String>();
        ArrayList<String> prevList = new ArrayList<String>();

        for (String course : prevList) {
            if (!newList.contains(course))
                newList.add(course);
        }
        return newList;
    }

    public static Courses getCourseWanted(ArrayList<Courses> completedCourses) {

        String neededCourse = StdIn.readLine();
        Courses desiredCourse = null;

        for (int i = 0; i < completedCourses.size(); i++) {
            if (completedCourses.get(i).getCourseName().equals(neededCourse))
                desiredCourse = completedCourses.get(i);
        }

        return desiredCourse;

    }

}