package prereqchecker;
import java.util.*;
import java.io.*;
/**
 * Steps to implement this class main method:
 * 
 * Step 1:
 * AdjListInputFile name is passed through the command line as args[0]
 * Read from AdjListInputFile with the format:
 * 1. a (int): number of courses in the graph
 * 2. a lines, each with 1 course ID
 * 3. b (int): number of edges in the graph
 * 4. b lines, each with a source ID
 * 
 * Step 2:
 * AdjListOutputFile name is passed through the command line as args[1]
 * Output to AdjListOutputFile with the format:
 * 1. c lines, each starting with a different course ID, then 
 *    listing all of that course's prerequisites (space separated)
 */
public class AdjList {
    ArrayList<ArrayList<String>> adjList = new ArrayList<>();
    ArrayList<String> adjacencyList = new ArrayList<>();

    public static void main(String[] args) {

        if ( args.length < 2 ) {
            StdOut.println("Execute: java -cp bin prereqchecker.AdjList <adjacency list INput file> <adjacency list OUTput file>");
            return;
        }
    
    // WRITE YOUR CODE HERE
        
        StdIn.setFile(args[0]); //sets the input file
        StdOut.setFile(args[1]); //creates the output file
        
        ArrayList<Courses> courseList = createListOfCourses(); //calls the list of courses method

        for (int i = 0; i < courseList.size(); i++)
        {
            StdOut.print(courseList.get(i).getCourseName() + " "); //prints the main course 
            for (int j = 0; j < courseList.get(i).getPreReqCourses().size(); j++)
            {
                StdOut.print(courseList.get(i).getPreReqCourses().get(j) + " "); //prints the prerequisite course
            }
            StdOut.println(); //newline 
        }

    }

    public static ArrayList<Courses> createListOfCourses()
    {
        int numOfCourses = StdIn.readInt();
        String courseName = StdIn.readLine();
        ArrayList<Courses> courseList = new ArrayList<Courses>();
        for (int i = 0; i < numOfCourses; i++)
        {
            courseName = StdIn.readLine();
            Courses courseID = new Courses();

            courseID.courses(courseName);
            courseList.add(courseID);
        }
        
        StdIn.readLine();

        while(!StdIn.isEmpty())
        {
            String currCourse = StdIn.readString();
            String preReqCourse = StdIn.readString();

            for (int i = 0; i < courseList.size(); i++)
            {
                if (courseList.get(i).getCourseName().equals(currCourse))
                {
                    courseList.get(i).addPreReqCourses(preReqCourse);
                    break;
                }
            }
        }
        return courseList;
    }
}