package prereqchecker;
import java.util.*;

/**
 * Steps to implement this class main method:
 * 
 * Step 1:
 * AdjListInputFile name is passed through the command line as args[0]
 * Read from AdjListInputFile with the format:
 * 1. a (int): number of courses in the graph
 * 2. a lines, each with 1 course ID
 * 3. b (int): number of edges in the graph
 * 4. b lines, each with a source ID
 * 
 * Step 2:
 * ValidPreReqInputFile name is passed through the command line as args[1]
 * Read from ValidPreReqInputFile with the format:
 * 1. 1 line containing the proposed advanced course
 * 2. 1 line containing the proposed prereq to the advanced course
 * 
 * Step 3:
 * ValidPreReqOutputFile name is passed through the command line as args[2]
 * Output to ValidPreReqOutputFile with the format:
 * 1. 1 line, containing either the word "YES" or "NO"
 */
public class ValidPrereq {
    public static void main(String[] args) {
        if ( args.length < 3 ) {
            StdOut.println("Execute: java -cp bin prereqchecker.ValidPrereq <adjacency list INput file> <valid prereq INput file> <valid prereq OUTput file>");
            return;
        }
	// WRITE YOUR CODE HERE
        StdIn.setFile(args[0]);
        StdIn.setFile(args[1]);
        StdOut.setFile(args[2]);

        ArrayList<Courses> courseList = new ArrayList<Courses>();
        
        boolean cycleDetector = validPreReq("adjlist.in", "validprereq.in", courseList);

        if (cycleDetector == false) {
            StdOut.println("NO");
        }
        else {
            StdOut.println("YES");
        }

    }

    public static boolean depthFirstSearch(String currCourse, int preReqCourse, boolean[] checkedCourse, ArrayList<Courses> courseList)
    {
        if (checkedCourse[preReqCourse])
        {
            return false;
        }
        checkedCourse[preReqCourse] = true;
        for (int i = 0; i < courseList.size(); i++)
        {
            if (i == preReqCourse)
            {
                ArrayList<Integer> preReqCourses = courseList.get(i).getNumOfPreReqs();

                for (int numOfPreReqs : preReqCourses)
                {
                    boolean cycleDetector = depthFirstSearch(currCourse, numOfPreReqs, checkedCourse, courseList);
                    if (cycleDetector == false)
                        return false;
                }
            }
        }
        return true;
    }

    public static boolean validPreReq(String course1, String course2, ArrayList<Courses> listOfCourses)
    {
        boolean[] cycleDetector = new boolean[listOfCourses.size()];
        for (int i = 0; i < listOfCourses.size(); i++)
        {
            if (listOfCourses.get(i).getCourseName().equals(course1))
            {
                if (!depthFirstSearch(course1, i, cycleDetector, listOfCourses))
                    return false;
                
            }
            if (listOfCourses.get(i).getCourseName().equals(course2))
            {
                if (!depthFirstSearch(course2, i, cycleDetector, listOfCourses))
                    return false;
            }
        }

        return true;
    }
}
