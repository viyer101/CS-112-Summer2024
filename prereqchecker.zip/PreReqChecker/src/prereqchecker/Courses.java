package prereqchecker;
import java.util.*;

public class Courses
{
    private String className;
    private ArrayList<String> requiredCourses = new ArrayList<String>();
    private ArrayList<Integer> numOfRequiredCourses = new ArrayList<Integer>();

    public void courses(String className)
    {
        this.className = className;
        this.requiredCourses = new ArrayList<String>();
        this.numOfRequiredCourses = new ArrayList<Integer>();
    }

    public String getCourseName()
    {
        return className;
    }

    public void addCourseName(String className)
    {
        this.requiredCourses.add(className);
    }

    public ArrayList<String> getPreReqCourses()
    {
        return this.requiredCourses;
    }

    public ArrayList<Integer> getNumOfPreReqs()
    {
        return this.numOfRequiredCourses;
    }

    public void addPreReqCourses(String preReqCourse)
    {
        this.requiredCourses.add(preReqCourse);
    }

    public void addNumOfPreReqs(int numOfPreReqs)
    {
        this.numOfRequiredCourses.add(numOfPreReqs);
    }
}